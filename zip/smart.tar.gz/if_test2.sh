#!/bin/sh
if [ "$SHELL"="/bin/bash" ] 
then

	echo "당신의 쉘은 본 쉘입니다."

else
	echo "당신의 쉘을 본 쉘이 아닙니다."
fi
