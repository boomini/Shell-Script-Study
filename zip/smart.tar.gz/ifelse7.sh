#!/bin/bash
if [ -x "/bin/cat" ]
then 
	echo  "실행가능하다"
else
	echo "실행이 불가능하다"
fi
