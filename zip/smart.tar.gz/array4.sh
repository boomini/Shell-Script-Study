#!/bin/bash

array=("apple" 200 3.14 400 "지옥으로 키티" 600) #배열 array 선언 및 초기화

echo array[0] = ${array[0]}				
echo array[1] = ${array[1]}				
echo array[2] = ${array[2]}				
echo array[3] = ${array[3]}				
echo array[4] = ${array[4]}				
echo array[5] = ${array[5]}				

