#!/bin/bash

function Normal
{
	echo "Normal call"
	return
}

Normal
