#!/bin/bash
if [ -d ~/code ]
then 
	echo  "~/code는 디렉터리다 "
else
	echo "~/code는 디렉터리가 아니다 "
fi
