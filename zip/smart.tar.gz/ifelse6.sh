#!/bin/bash
if [ -f ~/.vimrc ]
then 
	echo  "일반파일"
else
	echo "일반파일이아니다"
fi
