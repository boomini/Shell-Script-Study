#!/bin/sh
for VAL in 0 1 2 
do
	echo "VAL = ${VAL}"
done

