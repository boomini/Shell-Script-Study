#!/bin/bash

exec echo $(pwd)
#다음 줄은 실행 안됨
echo "=============================="
