#!/bin/sh
echo '$* : '$*
echo '$# : '$#
echo '$@ : '$@
echo " : $1 $2 $3"
