#!/bin/sh
case "$1" in 
	일)
		echo "1";;
	1) 
		echo "일";;
	*)
		echo "글쎄";;
esac

