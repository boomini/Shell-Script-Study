#!/bin/bash
if [ "bnk" != "BNK" ]
then 
	echo "BNK와 bnk는 다른문자다"
else
	echo "bnk와 BNK는  같다"
fi
