#!/bin/bash
if [ 1 -eq 10 ]
then 
	echo "1과 10은 같다"
else
	echo "1과 10은 다르다"
fi
