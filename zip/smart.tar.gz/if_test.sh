#!/bin/sh
if [ "$SHELL"="/bin/bash" ] 
then

echo "당신의 쉘은 본 쉘입니다."

fi
